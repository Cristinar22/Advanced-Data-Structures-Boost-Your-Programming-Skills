
# Real-Time Systems and Data Structure Choices
# Simulating Real-Time System for Request Processing

import threading
import time
from queue import Queue

class WebServer:
    def __init__(self, num_workers):
        self.request_queue = Queue()
        self.workers = [threading.Thread(target=self.process_requests) for _ in range(num_workers)]
        for worker in self.workers:
            worker.start()

    def process_requests(self):
        while True:
            request = self.request_queue.get()
            if request is None:
                break
            print(f"Processing request: {request}")
            time.sleep(1)  # Simulate processing time
            print(f"Completed request: {request}")

    def add_request(self, request):
        self.request_queue.put(request)

    def stop(self):
        for worker in self.workers:
            self.request_queue.put(None)
        for worker in self.workers:
            worker.join()

# Initialize web server and add requests
server = WebServer(num_workers=3)
server.add_request("Request 1")
server.add_request("Request 2")
server.stop()
