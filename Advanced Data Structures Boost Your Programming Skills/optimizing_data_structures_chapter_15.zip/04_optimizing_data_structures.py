
# Optimizing a Large-Scale System with Advanced Data Structures
# Priority Queue Implementation Example for Web Server

import heapq
from queue import PriorityQueue

class OptimizedWebServer:
    def __init__(self, num_workers):
        self.request_queue = PriorityQueue()
        self.workers = [threading.Thread(target=self.process_requests) for _ in range(num_workers)]
        for worker in self.workers:
            worker.start()

    def process_requests(self):
        while True:
            priority, request = self.request_queue.get()
            if request is None:
                break
            print(f"Processing high-priority request: {request}")
            time.sleep(1)
            print(f"Completed request: {request}")

    def add_request(self, request, priority):
        self.request_queue.put((priority, request))

    def stop(self):
        for worker in self.workers:
            self.request_queue.put((None, None))
        for worker in self.workers:
            worker.join()

# Simulate adding requests with different priorities
server = OptimizedWebServer(num_workers=3)
server.add_request("Low Priority Request", priority=2)
server.add_request("High Priority Request", priority=1)
server.stop()
