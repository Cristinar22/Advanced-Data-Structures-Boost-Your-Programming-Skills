
# Sample array
arr = [1, 3, 5, 7, 9, 11]

# Create the segment tree
seg_tree = SegmentTree(arr)

# Query the sum of the range [1, 3]
print(seg_tree.query(1, 3))  # Output: 15 (3 + 5 + 7)

# Update the value at index 2 to 6
seg_tree.update(2, 6)

# Query the sum of the range [1, 3] again after the update
print(seg_tree.query(1, 3))  # Output: 16 (3 + 6 + 7)
