from collections import deque

# Create a deque
dq = deque()

# Enqueue at the end
dq.append(10)
dq.append(20)
dq.append(30)

# Enqueue at the front
dq.appendleft(5)

print(dq)  # Output: deque([5, 10, 20, 30])

# Dequeue from the front
print(dq.popleft())  # Output: 5

# Dequeue from the end
print(dq.pop())  # Output: 30
