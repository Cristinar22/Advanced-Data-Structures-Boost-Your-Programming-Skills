class BrowserHistory:
    def __init__(self):
        self.history = Stack()
    
    def visit(self, url):
        self.history.push(url)
    
    def back(self):
        if not self.history.is_empty():
            return self.history.pop()
        return None
    
    def get_current_url(self):
        return self.history.peek()

# Example usage:
browser = BrowserHistory()
browser.visit("https://google.com")
browser.visit("https://stackoverflow.com")
browser.visit("https://github.com")

print(browser.get_current_url())  # Output: https://github.com
print(browser.back())  # Output: https://github.com (after popping)
print(browser.get_current_url())  # Output: https://stackoverflow.com
