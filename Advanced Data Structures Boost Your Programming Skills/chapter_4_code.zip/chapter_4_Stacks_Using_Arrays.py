class Stack:
    def __init__(self, size):
        self.stack = [None] * size  # Initialize the stack with None
        self.top = -1  # No elements yet
    
    def push(self, value):
        if self.top == len(self.stack) - 1:
            print("Stack Overflow!")
        else:
            self.top += 1
            self.stack[self.top] = value
    
    def pop(self):
        if self.top == -1:
            print("Stack Underflow!")
        else:
            value = self.stack[self.top]
            self.top -= 1
            return value
    
    def peek(self):
        if self.top == -1:
            return None
        return self.stack[self.top]
    
    def is_empty(self):
        return self.top == -1

# Example usage:
stack = Stack(5)
stack.push(10)
stack.push(20)
stack.push(30)
print(stack.pop())  # Output: 30
print(stack.peek())  # Output: 20
