
# Create a hash table
ht = HashTable()

# Insert some values
ht.insert("apple", 10)
ht.insert("banana", 20)
ht.insert("cherry", 30)

# Retrieve values
print(ht.get("apple"))   # Output: 10
print(ht.get("banana"))  # Output: 20
print(ht.get("cherry"))  # Output: 30
print(ht.get("grape"))   # Output: None
    