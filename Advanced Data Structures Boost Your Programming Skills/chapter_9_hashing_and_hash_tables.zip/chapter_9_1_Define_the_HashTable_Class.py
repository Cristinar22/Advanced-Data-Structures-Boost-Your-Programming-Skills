
class HashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [None] * size
    
    def hash_function(self, key):
        return hash(key) % self.size
    
    def insert(self, key, value):
        index = self.hash_function(key)
        if self.table[index] is None:
            self.table[index] = (key, value)
        else:
            # Handle collision by linear probing
            new_index = (index + 1) % self.size
            while self.table[new_index] is not None:
                new_index = (new_index + 1) % self.size
            self.table[new_index] = (key, value)
    
    def get(self, key):
        index = self.hash_function(key)
        if self.table[index] is None:
            return None
        elif self.table[index][0] == key:
            return self.table[index][1]
        else:
            # Linear probing to find the key
            new_index = (index + 1) % self.size
            while self.table[new_index] is not None:
                if self.table[new_index][0] == key:
                    return self.table[new_index][1]
                new_index = (new_index + 1) % self.size
            return None
    