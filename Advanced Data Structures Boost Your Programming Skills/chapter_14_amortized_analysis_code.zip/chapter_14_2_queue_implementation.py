
class Queue:
    def __init__(self):
        self.queue = []
    
    def enqueue(self, value):
        self.queue.append(value)  # O(1) amortized
    
    def dequeue(self):
        if not self.is_empty():
            return self.queue.pop(0)  # O(n) worst case
        else:
            raise IndexError("Queue is empty")
    
    def is_empty(self):
        return len(self.queue) == 0
