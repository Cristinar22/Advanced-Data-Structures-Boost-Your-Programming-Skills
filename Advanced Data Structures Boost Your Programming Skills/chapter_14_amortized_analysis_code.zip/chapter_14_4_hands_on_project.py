
arr = DynamicArray()

# Insert values
for i in range(1000):
    arr.insert(i)

# Delete values
for i in range(500):
    arr.delete()

# The amortized cost for each insert and delete remains O(1)
