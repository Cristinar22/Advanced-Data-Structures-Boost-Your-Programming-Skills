
class DynamicArray:
    def __init__(self):
        self.array = [None] * 2
        self.size = 0

    def insert(self, value):
        if self.size == len(self.array):
            self.resize()
        self.array[self.size] = value
        self.size += 1

    def resize(self):
        new_array = [None] * (len(self.array) * 2)
        for i in range(self.size):
            new_array[i] = self.array[i]
        self.array = new_array

    def get(self, index):
        if 0 <= index < self.size:
            return self.array[index]
        else:
            raise IndexError("Index out of bounds")
