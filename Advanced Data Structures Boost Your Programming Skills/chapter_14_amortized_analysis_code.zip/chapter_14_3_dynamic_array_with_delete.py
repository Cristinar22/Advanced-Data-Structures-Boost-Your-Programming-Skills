
class DynamicArray:
    def __init__(self):
        self.array = [None] * 2
        self.size = 0

    def insert(self, value):
        if self.size == len(self.array):
            self.resize()
        self.array[self.size] = value
        self.size += 1

    def delete(self):
        if self.size > 0:
            self.size -= 1
            if self.size == len(self.array) // 4:
                self.resize(shrink=True)
    
    def resize(self, shrink=False):
        new_size = len(self.array) * 2 if not shrink else len(self.array) // 2
        new_array = [None] * new_size
        for i in range(self.size):
            new_array[i] = self.array[i]
        self.array = new_array
