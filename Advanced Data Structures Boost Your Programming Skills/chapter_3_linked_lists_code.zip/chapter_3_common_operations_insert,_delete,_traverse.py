
        # Insertion at head
        def insert_at_head(self, value):
            new_node = Node(value)
            new_node.next = self.head
            self.head = new_node

        # Insertion at tail
        def insert_at_tail(self, value):
            new_node = Node(value)
            if not self.head:
                self.head = new_node
                return
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = new_node

        # Deletion from head
        def delete_at_head(self):
            if self.head:
                self.head = self.head.next

        # Deletion from tail
        def delete_at_tail(self):
            if not self.head:
                return
            temp = self.head
            while temp.next and temp.next.next:
                temp = temp.next
            temp.next = None

        # Traversal
        def traverse(self):
            temp = self.head
            while temp:
                print(temp.value, end=" -> ")
                temp = temp.next
    