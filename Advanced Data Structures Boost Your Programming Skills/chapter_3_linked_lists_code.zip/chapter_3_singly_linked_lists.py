
        # Singly Linked List insertion at head
        def insert_at_head(self, value):
            new_node = Node(value)
            new_node.next = self.head
            self.head = new_node

        # Singly Linked List insertion at tail
        def insert_at_tail(self, value):
            new_node = Node(value)
            if not self.head:
                self.head = new_node
                return
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = new_node
    