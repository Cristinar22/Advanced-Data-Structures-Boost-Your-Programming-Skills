
        # Doubly Linked List insertion and deletion
        class TaskNode:
            def __init__(self, task):
                self.task = task
                self.next = None
                self.prev = None

        class TaskList:
            def __init__(self):
                self.head = None
                self.tail = None

            def add_task(self, task):
                new_task = TaskNode(task)
                if not self.head:
                    self.head = self.tail = new_task
                else:
                    self.tail.next = new_task
                    new_task.prev = self.tail
                    self.tail = new_task

            def remove_task(self, task):
                current = self.head
                while current:
                    if current.task == task:
                        if current.prev:
                            current.prev.next = current.next
                        if current.next:
                            current.next.prev = current.prev
                        if current == self.head:
                            self.head = current.next
                        if current == self.tail:
                            self.tail = current.prev
                        return
                    current = current.next
                print(f"Task '{task}' not found.")
    