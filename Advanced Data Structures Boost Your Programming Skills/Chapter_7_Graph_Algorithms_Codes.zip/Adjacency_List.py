# Code for Adjacency List Representation
# Example graph
graph_list = {
    'A': ['B', 'D'],
    'B': ['A', 'C'],
    'C': ['B', 'D'],
    'D': ['A', 'C']
}

# Display the adjacency list
print("Adjacency List:")
for node, neighbors in graph_list.items():
    print(f"{node}: {neighbors}")
