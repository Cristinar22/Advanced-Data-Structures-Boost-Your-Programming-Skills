# Code for Social Network BFS and DFS

from collections import deque

# Create the social network graph
graph_social_network = {
    'Alice': ['Bob', 'Charlie'],
    'Bob': ['Alice', 'David'],
    'Charlie': ['Alice', 'Eve'],
    'David': ['Bob', 'Eve'],
    'Eve': ['Charlie', 'David']
}

# BFS Implementation
def bfs_social_network(graph, start):
    visited = set()
    queue = deque([start])
    visited.add(start)
    
    while queue:
        user = queue.popleft()
        print(f"Exploring {user}")
        
        for friend in graph[user]:
            if friend not in visited:
                visited.add(friend)
                queue.append(friend)

# DFS Implementation
def dfs_social_network(graph, start, visited=None):
    if visited is None:
        visited = set()
    visited.add(start)
    print(f"Exploring {start}")

    for friend in graph[start]:
        if friend not in visited:
            dfs_social_network(graph, friend, visited)

# Call BFS and DFS
bfs_social_network(graph_social_network, 'Alice')
dfs_social_network(graph_social_network, 'Alice')
