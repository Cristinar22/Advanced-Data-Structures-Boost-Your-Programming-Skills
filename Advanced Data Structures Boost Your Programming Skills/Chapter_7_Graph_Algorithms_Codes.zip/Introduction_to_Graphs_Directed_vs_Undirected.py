# Code for Directed vs Undirected Graphs
# Example of a directed graph representation
graph_directed = {
    'A': ['B'],
    'B': ['C'],
    'C': ['D'],
    'D': ['A']
}

# Example of an undirected graph representation
graph_undirected = {
    'A': ['B', 'D'],
    'B': ['A', 'C'],
    'C': ['B', 'D'],
    'D': ['A', 'C']
}
