# Code for Adjacency Matrix Representation
# Example graph
graph_matrix = {
    'A': ['B', 'D'],
    'B': ['A', 'C'],
    'C': ['B', 'D'],
    'D': ['A', 'C']
}

# Convert the graph to an adjacency matrix
nodes = list(graph_matrix.keys())
matrix = [[0 for _ in range(len(nodes))] for _ in range(len(nodes))]

# Populate the adjacency matrix
for i, node in enumerate(nodes):
    for neighbor in graph_matrix[node]:
        j = nodes.index(neighbor)
        matrix[i][j] = 1

# Display the adjacency matrix
print("Adjacency Matrix:")
for row in matrix:
    print(row)
