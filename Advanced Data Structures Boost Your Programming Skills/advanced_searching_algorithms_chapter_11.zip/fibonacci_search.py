
def fibonacci_search(arr, target):
    n = len(arr)
    fib_m_2 = 0
    fib_m_1 = 1
    fib = fib_m_2 + fib_m_1

    while fib < n:
        fib_m_2 = fib_m_1
        fib_m_1 = fib
        fib = fib_m_2 + fib_m_1

    offset = -1
    while fib > 1:
        i = min(offset + fib_m_2, n-1)
        
        if arr[i] < target:
            fib = fib_m_1
            fib_m_1 = fib_m_2
            fib_m_2 = fib - fib_m_1
            offset = i
        elif arr[i] > target:
            fib = fib_m_2
            fib_m_1 = fib_m_1 - fib_m_2
            fib_m_2 = fib - fib_m_1
        else:
            return i
    if fib_m_1 and arr[offset+1] == target:
        return offset+1
    return -1  # Target not found
