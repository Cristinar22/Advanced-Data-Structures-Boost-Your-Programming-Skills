
import random

# Generate a large sorted list of random integers
data = sorted([random.randint(1, 100000) for _ in range(10000)])

target = random.choice(data)

# Test each search algorithm
print("Binary Search Result:", binary_search(data, target))
print("Exponential Search Result:", exponential_search(data, target))
print("Interpolation Search Result:", interpolation_search(data, target))
print("Fibonacci Search Result:", fibonacci_search(data, target))
