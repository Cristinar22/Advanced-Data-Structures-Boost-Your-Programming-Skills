
    def append(self, value):
        # Check if the array is full
        if self.length == self.size:
            self.resize()
        # Add the element at the next available position
        self.array[self.length] = value
        self.length += 1
