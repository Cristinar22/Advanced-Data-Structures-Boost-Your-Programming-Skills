
    def pop(self):
        if self.length == 0:
            raise IndexError("pop from empty array")
        self.length -= 1
        value = self.array[self.length]
        self.array[self.length] = None
        return value
