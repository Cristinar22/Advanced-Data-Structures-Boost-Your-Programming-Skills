
class DynamicArray:
    def __init__(self):
        # Start with an array of size 2
        self.size = 2
        self.array = [None] * self.size
        self.length = 0

    def __str__(self):
        return str(self.array[:self.length])
