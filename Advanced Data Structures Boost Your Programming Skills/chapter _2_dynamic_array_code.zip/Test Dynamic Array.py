
# Create a dynamic array
dynamic_array = DynamicArray()

# Append elements
dynamic_array.append(1)
dynamic_array.append(2)
print(dynamic_array)  # Output: [1, 2]

dynamic_array.append(3)  # The array will resize automatically
print(dynamic_array)  # Output: [1, 2, 3]
