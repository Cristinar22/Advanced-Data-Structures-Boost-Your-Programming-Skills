
    def resize(self):
        # Create a new array with double the size
        new_size = self.size * 2
        new_array = [None] * new_size
        # Copy elements from the old array to the new array
        for i in range(self.length):
            new_array[i] = self.array[i]
        self.array = new_array
        self.size = new_size
