
# Create a priority queue
pq = PriorityQueue()

# Add some tasks with different priorities
pq.push(Task("Do laundry", 3))
pq.push(Task("Complete homework", 1))
pq.push(Task("Cook dinner", 2))

# Process tasks based on priority
while not pq.is_empty():
    task = pq.pop()
    print(f"Processing: {task}")
    