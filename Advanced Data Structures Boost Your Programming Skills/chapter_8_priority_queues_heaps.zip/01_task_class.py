
class Task:
    def __init__(self, description, priority):
        self.description = description
        self.priority = priority
    
    def __lt__(self, other):
        # This is required for the priority queue to compare tasks by priority
        return self.priority < other.priority
    
    def __repr__(self):
        return f"Task(description: '{self.description}', priority: {self.priority})"
    