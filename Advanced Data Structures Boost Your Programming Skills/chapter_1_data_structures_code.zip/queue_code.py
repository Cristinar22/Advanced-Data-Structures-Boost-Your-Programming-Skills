class Queue:
    def __init__(self):
        self.queue = []
    
    def enqueue(self, item):
        self.queue.append(item)
    
    def dequeue(self):
        if len(self.queue) > 0:
            return self.queue.pop(0)
        return "Queue is empty"
    
    def front(self):
        if len(self.queue) > 0:
            return self.queue[0]
        return "Queue is empty"
    
    def is_empty(self):
        return len(self.queue) == 0

# Example usage
queue = Queue()
queue.enqueue(10)
queue.enqueue(20)
print(queue.dequeue())  # Outputs 10
print(queue.front())  # Outputs 20
