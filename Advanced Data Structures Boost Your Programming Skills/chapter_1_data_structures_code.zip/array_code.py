# Let's create an array of numbers
numbers = [10, 20, 30, 40, 50]

# Accessing elements
print(numbers[0])  # This will print 10, the first element

# Adding a new element
numbers.append(60)
print(numbers)  # Now the array contains [10, 20, 30, 40, 50, 60]

# Removing an element
numbers.remove(30)
print(numbers)  # Now the array contains [10, 20, 40, 50, 60]
