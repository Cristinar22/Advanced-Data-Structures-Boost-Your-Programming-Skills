class Stack:
    def __init__(self):
        self.stack = []
    
    def push(self, item):
        self.stack.append(item)
    
    def pop(self):
        if len(self.stack) > 0:
            return self.stack.pop()
        return "Stack is empty"
    
    def peek(self):
        if len(self.stack) > 0:
            return self.stack[-1]
        return "Stack is empty"
    
    def is_empty(self):
        return len(self.stack) == 0

# Example usage
stack = Stack()
stack.push(10)
stack.push(20)
print(stack.pop())  # Outputs 20
print(stack.peek())  # Outputs 10
