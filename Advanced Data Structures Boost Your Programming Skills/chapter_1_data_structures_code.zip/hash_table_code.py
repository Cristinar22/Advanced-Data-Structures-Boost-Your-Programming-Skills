class HashTable:
    def __init__(self):
        self.size = 10
        self.table = [None] * self.size

    def hash_function(self, key):
        return key % self.size

    def insert(self, key, value):
        index = self.hash_function(key)
        self.table[index] = value

    def get(self, key):
        index = self.hash_function(key)
        return self.table[index]

# Example usage
hash_table = HashTable()
hash_table.insert(1, "One")
hash_table.insert(11, "Eleven")
print(hash_table.get(1))  # Outputs: One
print(hash_table.get(11))  # Outputs: Eleven
