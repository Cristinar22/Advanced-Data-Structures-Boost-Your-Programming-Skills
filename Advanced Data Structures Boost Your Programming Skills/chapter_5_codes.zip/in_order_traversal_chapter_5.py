
def in_order(node):
    if node:
        in_order(node.left)        # Traverse the left subtree
        print(node.value, end=" ")  # Visit the root node
        in_order(node.right)       # Traverse the right subtree
