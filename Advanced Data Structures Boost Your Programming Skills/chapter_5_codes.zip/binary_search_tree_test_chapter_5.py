
# Create a binary search tree
bst = BinarySearchTree()

# Insert values
bst.insert(10)
bst.insert(20)
bst.insert(5)
bst.insert(8)

# Search for values
result = bst.search(5)
if result:
    print(f"Found: {result.value}")
else:
    print("Not found")

result = bst.search(15)
if result:
    print(f"Found: {result.value}")
else:
    print("Not found")
