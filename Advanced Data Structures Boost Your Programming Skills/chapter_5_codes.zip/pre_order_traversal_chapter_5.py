
def pre_order(node):
    if node:
        print(node.value, end=" ")  # Visit the root node
        pre_order(node.left)        # Traverse the left subtree
        pre_order(node.right)       # Traverse the right subtree
