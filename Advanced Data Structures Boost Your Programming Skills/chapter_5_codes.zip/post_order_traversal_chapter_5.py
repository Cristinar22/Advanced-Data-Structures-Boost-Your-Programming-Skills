
def post_order(node):
    if node:
        post_order(node.left)       # Traverse the left subtree
        post_order(node.right)      # Traverse the right subtree
        print(node.value, end=" ")   # Visit the root node
