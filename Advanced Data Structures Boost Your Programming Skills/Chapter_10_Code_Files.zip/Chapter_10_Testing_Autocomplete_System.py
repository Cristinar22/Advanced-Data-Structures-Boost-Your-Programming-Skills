
# Create the autocomplete system
system = AutocompleteSystem()

# Add some words
system.add_word("cat")
system.add_word("car")
system.add_word("dog")
system.add_word("dogma")
system.add_word("dorm")

# Autocomplete suggestions
print(system.autocomplete("ca"))  # ['cat', 'car']
print(system.autocomplete("do"))  # ['dog', 'dogma', 'dorm']
print(system.autocomplete("doe"))  # []
