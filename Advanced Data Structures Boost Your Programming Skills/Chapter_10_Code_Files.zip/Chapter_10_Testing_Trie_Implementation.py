
# Create a new trie
trie = Trie()

# Insert words into the trie
trie.insert("cat")
trie.insert("car")
trie.insert("dog")

# Search for words
print(trie.search("cat"))  # True
print(trie.search("car"))  # True
print(trie.search("dog"))  # True
print(trie.search("do"))   # False

# Check for prefixes
print(trie.starts_with("ca"))  # True
print(trie.starts_with("do"))  # True
print(trie.starts_with("da"))  # False
