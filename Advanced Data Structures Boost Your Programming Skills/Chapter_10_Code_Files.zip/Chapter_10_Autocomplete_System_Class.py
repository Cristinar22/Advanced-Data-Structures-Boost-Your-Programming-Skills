
class AutocompleteSystem:
    def __init__(self):
        self.trie = Trie()

    def add_word(self, word):
        self.trie.insert(word)

    def autocomplete(self, prefix):
        current = self.trie.root
        for char in prefix:
            if char not in current.children:
                return []
            current = current.children[char]

        # Now, we need to collect all words starting with the prefix
        return self._collect_words(current, prefix)

    def _collect_words(self, node, prefix):
        words = []
        if node.is_end_of_word:
            words.append(prefix)

        for char, child in node.children.items():
            words += self._collect_words(child, prefix + char)
        
        return words
