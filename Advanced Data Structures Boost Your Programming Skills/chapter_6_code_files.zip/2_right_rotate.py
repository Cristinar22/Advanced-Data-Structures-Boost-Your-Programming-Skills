def right_rotate(x):
    y = x.left
    x.left = y.right
    y.right = x
    return y  # New root of the subtree