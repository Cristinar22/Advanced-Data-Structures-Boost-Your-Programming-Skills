rbt = RedBlackTree()
rbt.insert(20)
rbt.insert(15)
rbt.insert(25)
rbt.insert(10)
rbt.insert(5)

# Now the Red-Black Tree is balanced and values can be searched efficiently