def left_rotate(x):
    y = x.right
    x.right = y.left
    y.left = x
    return y  # New root of the subtree